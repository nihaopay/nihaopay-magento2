var config = {
    map: {
        '*': {
           nihaopay: 'https://nihaopay.com/lib/js/nihaopay.min.js',
        }
    }
};
