<?php

namespace Nihaopay\Payments\Model\Error;

class Error_Api extends MyErrorBase
{
}
