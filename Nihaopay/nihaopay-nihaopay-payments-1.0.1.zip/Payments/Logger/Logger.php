<?php

namespace Nihaopay\Payments\Logger;
 
class Logger extends \Monolog\Logger
{
}